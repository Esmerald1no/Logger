# Logger
Logger Module for my projects, but feel free to use it.

Features support for basic formatting (Bold, Underline, Italic, and Font Color) for messages.

Compatible with most terminals.

Requires Python 3.10 or higher.
